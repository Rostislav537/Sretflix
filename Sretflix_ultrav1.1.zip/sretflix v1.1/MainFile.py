from  tkinter import *
import TkinterLib
root=Tk()
f=TkinterLib.Visual(root, '5162942651a62a2b8f8043b5ea2ee4bd')
f.take_rootmenu()
mainloop()